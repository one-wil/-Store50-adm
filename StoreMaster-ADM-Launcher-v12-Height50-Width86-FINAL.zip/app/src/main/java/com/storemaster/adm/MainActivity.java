package com.storemaster.adm;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends Activity {
    private static final String PREFS = "storemaster_launcher";
    private static final String KEY_ALIAS = "StoreMasterPasswordKey";
    private EditText admUrl, shopUrl, passwordInput;
    private SharedPreferences prefs;

    private final int BG = Color.rgb(15, 17, 35);
    private final int CARD = Color.rgb(30, 33, 58);
    private final int CARD2 = Color.rgb(42, 46, 78);
    private final int WHITE = Color.WHITE;
    private final int MUTED = Color.rgb(195, 198, 214);
    private final int BLUE = Color.rgb(67, 97, 238);
    private final int GREEN = Color.rgb(24, 168, 112);
    private final int GRAY = Color.rgb(82, 87, 113);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        showLauncher();
    }

    private GradientDrawable rounded(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String s, float size, boolean bold, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setTypeface(Typeface.create("sans-serif", bold ? Typeface.BOLD : Typeface.NORMAL));
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(true);
        t.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return t;
    }

    private EditText urlInput(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("https://...");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(dp(16), 0, dp(16), 0);
        e.setBackground(rounded(Color.WHITE, 18));
        return e;
    }

    private EditText passwordField(String value) {
        EditText e = new EditText(this);
        e.setText(value);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setTextColor(Color.rgb(30, 32, 45));
        e.setHintTextColor(Color.rgb(125, 128, 140));
        e.setHint("كلمة مرور لوحة التحكم");
        e.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        e.setTextDirection(View.TEXT_DIRECTION_LTR);
        e.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);
        e.setPadding(dp(14), 0, dp(14), 0);
        e.setBackground(rounded(Color.WHITE, 17));
        return e;
    }

    private CheckBox lockBox(boolean checked) {
        CheckBox c = new CheckBox(this);
        c.setText("قفل");
        c.setTextSize(14);
        c.setTextColor(WHITE);
        c.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        c.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        c.setButtonTintList(new ColorStateList(
                new int[][] { new int[]{android.R.attr.state_checked}, new int[]{} },
                new int[] { BLUE, Color.rgb(150, 154, 170) }
        ));
        c.setChecked(checked);
        c.setPadding(0, 0, 0, 0);
        c.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return c;
    }

    private Button actionButton(String value, int color, int height) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(17);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        b.setGravity(Gravity.CENTER);
        b.setIncludeFontPadding(true);
        b.setMinHeight(0);
        b.setMinWidth(0);
        b.setPadding(12, 0, 12, 0);
        b.setBackground(rounded(color, 18));
        b.setStateListAnimator(null);
        return b;
    }

    private void addGap(LinearLayout root, int dp) {
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, vdp(dp)));
    }

    /** A clean section: title, generous gap, input, then lock on its own line. */
    private void addUrlSection(LinearLayout root, String title, EditText input, CheckBox lock) {
        TextView t = text(title, 17, true, WHITE);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setPadding(0, 0, dp(2), 0);
        root.addView(t, new LinearLayout.LayoutParams(-1, vdp(43)));
        addGap(root, 13);
        root.addView(input, new LinearLayout.LayoutParams(-1, vdp(52)));
        addGap(root, 7);

        // Physical placement is fixed: URL locks are always on the RIGHT side,
        // regardless of RTL/LTR layout direction or device size.
        LinearLayout lockRow = new LinearLayout(this);
        lockRow.setOrientation(LinearLayout.HORIZONTAL);
        lockRow.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        lockRow.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(dp(82), vdp(38));
        lockRow.addView(lock, lockLp);
        root.addView(lockRow, new LinearLayout.LayoutParams(-1, vdp(38)));
    }

    /** Password row: lock on the right, field in the middle, copy on the left. */
    private void addPasswordSection(LinearLayout root, EditText field, CheckBox lock, ImageButton copy) {
        TextView title = text("كلمة مرور لوحة التحكم", 17, true, WHITE);
        title.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        root.addView(title, new LinearLayout.LayoutParams(-1, vdp(43)));
        addGap(root, 13);

        // Password: physical RIGHT = lock, physical LEFT = copy.
        // LTR container makes the physical positions deterministic on RTL devices.
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        LinearLayout.LayoutParams copyLp = new LinearLayout.LayoutParams(dp(52), vdp(50));
        copyLp.setMargins(0, 0, dp(8), 0);
        row.addView(copy, copyLp);

        LinearLayout.LayoutParams fieldLp = new LinearLayout.LayoutParams(0, vdp(56), 1f);
        row.addView(field, fieldLp);

        LinearLayout.LayoutParams lockLp = new LinearLayout.LayoutParams(dp(72), vdp(50));
        lockLp.setMargins(dp(7), 0, 0, 0);
        row.addView(lock, lockLp);

        root.addView(row, new LinearLayout.LayoutParams(-1, vdp(50)));
        addGap(root, 11);
    }

    private ImageButton copyButton() {
        ImageButton b = new ImageButton(this);
        b.setImageResource(com.storemaster.adm.R.drawable.ic_copy);
        b.setContentDescription("نسخ كلمة المرور");
        b.setColorFilter(WHITE);
        b.setBackground(rounded(CARD2, 17));
        b.setPadding(dp(12), vdp(11), dp(12), vdp(11));
        b.setScaleType(ImageButton.ScaleType.CENTER_INSIDE);
        return b;
    }

    private void showLauncher() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(BG);
        int horizontalMargin = (int) (getResources().getDisplayMetrics().widthPixels * 0.07f + 0.5f);
        root.setPadding(horizontalMargin, vdp(14), horizontalMargin, vdp(18));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setClipToPadding(false);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER_HORIZONTAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(0, vdp(40), 0, vdp(18));

        int screenWidthDp = (int) (getResources().getDisplayMetrics().widthPixels /
                getResources().getDisplayMetrics().density + 0.5f);

        // Stage 1: brand animation. Other stages are INVISIBLE until their turn.
        TextView title = text("StoreMaster ADM", 30, true, WHITE);
        title.setGravity(Gravity.CENTER);
        title.setAlpha(0f);
        title.setTranslationY(-25f);
        title.setScaleX(0.88f);
        title.setScaleY(0.88f);
        content.addView(title, new LinearLayout.LayoutParams(-1, vdp(83)));

        addGap(content, 9);

        TextView sub = text("إعداد روابط لوحة الإدارة والبوتيك", 16, false, MUTED);
        sub.setGravity(Gravity.CENTER);
        sub.setVisibility(View.INVISIBLE);
        content.addView(sub, new LinearLayout.LayoutParams(-1, vdp(47)));
        addGap(content, 25);

        // ===== Main action buttons =====
        Button openAdm = actionButton("دخول إلى ADM", BLUE, 58);
        Button openShop = actionButton("فتح البوتيك", GREEN, 58);
        Button save = actionButton("حفظ الإعدادات", GRAY, 56);
        TextView note = text("بعد قفل الرابط أو كلمة المرور، لن يمكن تعديلها حتى يتم إلغاء القفل.", 13, false, MUTED);
        note.setGravity(Gravity.CENTER);

        openAdm.setVisibility(View.INVISIBLE);
        openShop.setVisibility(View.INVISIBLE);
        save.setVisibility(View.INVISIBLE);
        note.setVisibility(View.INVISIBLE);

        int buttonWidthDp = Math.min(330, Math.max(220, screenWidthDp - 48));
        int buttonWidth = dp(buttonWidthDp);

        // ===== Exact page order from the supplied screenshots =====
        // Title -> subtitle -> ADM -> Boutique -> Password -> security note -> URLs -> Save -> lock note -> support
        content.addView(openAdm, centeredParams(buttonWidth, vdp(52)));
        addGap(content, 13);
        content.addView(openShop, centeredParams(buttonWidth, vdp(52)));
        addGap(content, 13);

        // ===== Password card: directly below the Boutique button =====
        LinearLayout passwordCard = new LinearLayout(this);
        passwordCard.setOrientation(LinearLayout.VERTICAL);
        passwordCard.setPadding(dp(16), vdp(18), dp(16), vdp(18));
        passwordCard.setBackground(rounded(CARD, 23));
        passwordCard.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        passwordCard.setVisibility(View.INVISIBLE);

        passwordInput = passwordField(decryptPassword(prefs.getString("password_enc", "")));
        CheckBox passwordLock = lockBox(prefs.getBoolean("password_locked", false));
        ImageButton copyPassword = copyButton();
        addPasswordSection(passwordCard, passwordInput, passwordLock, copyPassword);

        int cardWidthDp = Math.min(560, Math.max(220, screenWidthDp - 24));
        content.addView(passwordCard, new LinearLayout.LayoutParams(
                dp(cardWidthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(content, 9);

        // ===== Security note =====
        TextView secure = text("تُحفظ كلمة المرور محليًا بشكل مشفّر ولا تظهر كنص عادي.", 13, false, MUTED);
        secure.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        secure.setVisibility(View.INVISIBLE);
        content.addView(secure, new LinearLayout.LayoutParams(-1, vdp(36)));
        addGap(content, 16);

        // ===== URL settings card =====
        LinearLayout urlCard = new LinearLayout(this);
        urlCard.setOrientation(LinearLayout.VERTICAL);
        urlCard.setPadding(dp(16), vdp(18), dp(16), vdp(18));
        urlCard.setBackground(rounded(CARD, 23));
        urlCard.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        urlCard.setVisibility(View.INVISIBLE);

        admUrl = urlInput(prefs.getString("adm", ""));
        shopUrl = urlInput(prefs.getString("shop", ""));
        CheckBox admLock = lockBox(prefs.getBoolean("adm_locked", false));
        CheckBox shopLock = lockBox(prefs.getBoolean("shop_locked", false));

        addUrlSection(urlCard, "رابط لوحة الإدارة ADM", admUrl, admLock);
        addGap(urlCard, 18);
        addUrlSection(urlCard, "رابط البوتيك", shopUrl, shopLock);

        content.addView(urlCard, new LinearLayout.LayoutParams(
                dp(cardWidthDp), ViewGroup.LayoutParams.WRAP_CONTENT));
        addGap(content, 25);

        // ===== Save settings remains below the URL card =====
        content.addView(save, centeredParams(buttonWidth, vdp(50)));
        addGap(content, 16);
        content.addView(note, new LinearLayout.LayoutParams(-1, vdp(43)));
        addGap(content, 7);

        // ===== Support footer: bottom-left, small text, no colon =====
        TextView support = text(
                "Contacter support\nA.BENAKRAB\n0551102155 / 0671466489",
                11, false, MUTED);
        support.setVisibility(View.INVISIBLE);
        support.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        support.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_START);
        support.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        support.setLineSpacing(vdp(2), 1.0f);
        LinearLayout.LayoutParams supportLp = new LinearLayout.LayoutParams(-1, vdp(54));
        supportLp.gravity = Gravity.LEFT;
        content.addView(support, supportLp);

        scroll.addView(content, new ScrollView.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        admUrl.setEnabled(!admLock.isChecked());
        shopUrl.setEnabled(!shopLock.isChecked());
        passwordInput.setEnabled(!passwordLock.isChecked());

        admLock.setOnCheckedChangeListener((button, checked) -> {
            admUrl.setEnabled(!checked);
            prefs.edit().putBoolean("adm_locked", checked).apply();
            if (checked) saveSettings();
        });
        shopLock.setOnCheckedChangeListener((button, checked) -> {
            shopUrl.setEnabled(!checked);
            prefs.edit().putBoolean("shop_locked", checked).apply();
            if (checked) saveSettings();
        });
        passwordLock.setOnCheckedChangeListener((button, checked) -> {
            passwordInput.setEnabled(!checked);
            prefs.edit().putBoolean("password_locked", checked).apply();
            if (checked) saveSettings();
        });

        copyPassword.setOnClickListener(v -> copyPasswordToClipboard());
        save.setOnClickListener(v -> saveSettings());
        openAdm.setOnClickListener(v -> openUrl(admUrl.getText().toString().trim(), true));
        openShop.setOnClickListener(v -> openUrl(shopUrl.getText().toString().trim(), false));

        setContentView(root);

        // Smooth opening follows the exact visual order above.
        title.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                .setDuration(850).setInterpolator(new DecelerateInterpolator()).start();

        title.postDelayed(() -> reveal(sub, 420, 0f, 13f), 900);
        title.postDelayed(() -> {
            reveal(openAdm, 280, 0f, 16f);
            openAdm.postDelayed(() -> reveal(openShop, 280, 0f, 16f), 90);
            openShop.postDelayed(() -> reveal(passwordCard, 420, 0f, 16f), 180);
            passwordCard.postDelayed(() -> reveal(secure, 300, 0f, 9f), 520);
            secure.postDelayed(() -> reveal(urlCard, 560, 0f, 16f), 820);
            urlCard.postDelayed(() -> reveal(save, 280, 0f, 16f), 1450);
            save.postDelayed(() -> reveal(note, 280, 0f, 9f), 1740);
            note.postDelayed(() -> reveal(support, 280, 0f, 9f), 2080);
        }, 1350);
    }

    private void reveal(View v, long duration, float alphaFrom, float yFrom) {
        v.setVisibility(View.VISIBLE);
        v.setAlpha(alphaFrom);
        v.setTranslationY(yFrom);
        v.animate().alpha(1f).translationY(0f).setDuration(duration)
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private LinearLayout.LayoutParams centeredParams(int width, int height) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width, height);
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int vdp(int value) {
        // Vertical size is 50% of the original V12 baseline. Horizontal width is handled separately.
        return (int) (value * getResources().getDisplayMetrics().density * (50f / 90f) + 0.5f);
    }

    private void saveSettings() {
        String password = passwordInput == null ? "" : passwordInput.getText().toString();
        String encrypted = encryptPassword(password);
        prefs.edit()
                .putString("adm", admUrl.getText().toString().trim())
                .putString("shop", shopUrl.getText().toString().trim())
                .putString("password_enc", encrypted)
                .apply();
        Toast.makeText(this, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show();
    }

    private void copyPasswordToClipboard() {
        String password = passwordInput.getText().toString();
        if (password.isEmpty()) password = decryptPassword(prefs.getString("password_enc", ""));
        if (password.isEmpty()) {
            Toast.makeText(this, "أدخل كلمة المرور أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("StoreMaster ADM", password));
        Toast.makeText(this, "تم نسخ كلمة المرور", Toast.LENGTH_SHORT).show();
    }

    private SecretKey getOrCreateKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build());
        return kg.generateKey();
    }

    private String encryptPassword(String plain) {
        if (plain == null || plain.isEmpty()) return "";
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey());
            byte[] encrypted = cipher.doFinal(plain.getBytes(StandardCharsets.UTF_8));
            byte[] iv = cipher.getIV();
            return Base64.encodeToString(iv, Base64.NO_WRAP) + ":" + Base64.encodeToString(encrypted, Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    private String decryptPassword(String stored) {
        if (stored == null || stored.isEmpty() || !stored.contains(":")) return "";
        try {
            String[] parts = stored.split(":", 2);
            byte[] iv = Base64.decode(parts[0], Base64.NO_WRAP);
            byte[] data = Base64.decode(parts[1], Base64.NO_WRAP);
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(data), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }

    private void openUrl(String url, boolean adm) {
        if (url.isEmpty()) {
            Toast.makeText(this, adm ? "أدخل رابط ADM أولاً" : "أدخل رابط البوتيك أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!url.startsWith("https://") && !url.startsWith("http://")) url = "https://" + url;
        prefs.edit().putString(adm ? "adm" : "shop", url).apply();

        WebView w = new WebView(this);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        w.setWebViewClient(new android.webkit.WebViewClient());
        w.loadUrl(url);
        setContentView(w);
    }

    @Override public void onBackPressed() { showLauncher(); }
}
